var searchData=
[
  ['impassable_0',['Impassable',['../namespace_snails.html#a19c9f722b6fd33b087d81babfe6ec256a02518d4f54df131d84d3b77bcb2bdce4',1,'Snails']]],
  ['iplayeragent_1',['IPlayerAgent',['../interface_snails_1_1_agent_1_1_i_player_agent.html',1,'Snails::Agent']]],
  ['iplayercommand_2',['IPlayerCommand',['../interface_snails_1_1_agent_1_1_i_player_command.html',1,'Snails::Agent']]],
  ['iworldstate_3',['IWorldState',['../interface_snails_1_1_i_world_state.html',1,'Snails']]]
];

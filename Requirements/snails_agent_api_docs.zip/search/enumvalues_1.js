var searchData=
[
  ['impassable_0',['Impassable',['../namespace_snails.html#a19c9f722b6fd33b087d81babfe6ec256a02518d4f54df131d84d3b77bcb2bdce4',1,'Snails']]]
];

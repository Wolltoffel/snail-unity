var indexSectionsWithContent =
{
  0: "cdeilmnoprstuvwxyz",
  1: "cinptvw",
  2: "s",
  3: "cotvw",
  4: "dlmruz",
  5: "c",
  6: "eist",
  7: "cdenopstxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties"
};


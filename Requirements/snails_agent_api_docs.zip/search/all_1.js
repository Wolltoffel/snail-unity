var searchData=
[
  ['delta_0',['Delta',['../interface_snails_1_1_agent_1_1_i_player_command.html#a96dbbc64ec79a7315299a4aa5ce284ac',1,'Snails::Agent::IPlayerCommand']]],
  ['down_1',['Down',['../struct_snails_1_1_vec2_int.html#a329355f5f5e6fba65ec5a49847116f36',1,'Snails::Vec2Int']]]
];

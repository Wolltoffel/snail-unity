var searchData=
[
  ['operator_20byte_0',['operator byte',['../struct_snails_1_1_tile_data.html#a2b318e8ea4f28d82a76b29e1b569c425',1,'Snails::TileData']]],
  ['origin_1',['Origin',['../interface_snails_1_1_agent_1_1_i_player_command.html#a2f87ab050b29e82fdae754a657abe666',1,'Snails::Agent::IPlayerCommand']]]
];

var searchData=
[
  ['iplayeragent_0',['IPlayerAgent',['../interface_snails_1_1_agent_1_1_i_player_agent.html',1,'Snails::Agent']]],
  ['iplayercommand_1',['IPlayerCommand',['../interface_snails_1_1_agent_1_1_i_player_command.html',1,'Snails::Agent']]],
  ['iworldstate_2',['IWorldState',['../interface_snails_1_1_i_world_state.html',1,'Snails']]]
];

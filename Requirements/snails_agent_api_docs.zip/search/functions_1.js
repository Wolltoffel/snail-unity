var searchData=
[
  ['operator_20byte_0',['operator byte',['../struct_snails_1_1_tile_data.html#a2b318e8ea4f28d82a76b29e1b569c425',1,'Snails::TileData']]]
];

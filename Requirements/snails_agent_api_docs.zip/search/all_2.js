var searchData=
[
  ['empty_0',['Empty',['../struct_snails_1_1_tile_data.html#a48094ab4913b0c106da6052fd12109a1',1,'Snails.TileData.Empty()'],['../namespace_snails.html#a19c9f722b6fd33b087d81babfe6ec256ace2c8aed9c2fa0cfbed56cbda4d8bf07',1,'Snails.Empty()']]]
];

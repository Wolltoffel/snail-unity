var searchData=
[
  ['zero_0',['Zero',['../struct_snails_1_1_vec2_int.html#a777484df350a9b757a090533d5140b8f',1,'Snails::Vec2Int']]]
];

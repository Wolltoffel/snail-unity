var searchData=
[
  ['contents_0',['Contents',['../struct_snails_1_1_tile_data.html#ab8675a7a7e36c1046f803285f6d7eddb',1,'Snails::TileData']]],
  ['cputimeused_1',['CpuTimeUsed',['../class_snails_1_1_agent_1_1_player_agent.html#a0b1923e3f32d8233a0ac8ab335f17eb0',1,'Snails::Agent::PlayerAgent']]]
];

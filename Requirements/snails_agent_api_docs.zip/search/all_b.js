var searchData=
[
  ['this_5bint_20x_2c_20int_20y_5d_0',['this[int x, int y]',['../interface_snails_1_1_i_world_state.html#a585750ce9e25d380dcf3ac6bc0fb2c8f',1,'Snails.IWorldState.this[int x, int y]()'],['../class_snails_1_1_world_state.html#a1378d93b761963ea067bb0e62f9b28c1',1,'Snails.WorldState.this[int x, int y]()']]],
  ['tiledata_1',['TileData',['../struct_snails_1_1_tile_data.html',1,'Snails.TileData'],['../struct_snails_1_1_tile_data.html#a23fb19a74a028e7a6e04208664e0b2f3',1,'Snails.TileData.TileData(ContentType contents, uint player=0)'],['../struct_snails_1_1_tile_data.html#aa457ca49f2f90de6fd6647a4df7cd1b7',1,'Snails.TileData.TileData(byte data)']]],
  ['tostring_2',['ToString',['../struct_snails_1_1_tile_data.html#aa6eb7bf0959d58c9e820d76153313a0e',1,'Snails.TileData.ToString()'],['../struct_snails_1_1_vec2_int.html#a3c045cc1195685fc1424db753e56e7fc',1,'Snails.Vec2Int.ToString()']]],
  ['trail_3',['Trail',['../namespace_snails.html#a19c9f722b6fd33b087d81babfe6ec256ad518a06262ac68f1f006a4f802588130',1,'Snails']]],
  ['turn_4',['Turn',['../interface_snails_1_1_i_world_state.html#a5597579c806f7fce390fa652e54c412b',1,'Snails.IWorldState.Turn()'],['../class_snails_1_1_world_state.html#a392f0f540fbb5af53b35ce6a2ae1de2c',1,'Snails.WorldState.Turn()']]]
];

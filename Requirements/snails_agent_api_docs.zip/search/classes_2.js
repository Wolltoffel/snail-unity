var searchData=
[
  ['negamaxagent_0',['NegamaxAgent',['../class_snails_1_1_agent_1_1_negamax_agent.html',1,'Snails::Agent']]]
];

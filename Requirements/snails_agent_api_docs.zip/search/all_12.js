var searchData=
[
  ['y_0',['Y',['../struct_snails_1_1_vec2_int.html#a9c3f750051cc7fdc2ff84d2565147f49',1,'Snails::Vec2Int']]]
];

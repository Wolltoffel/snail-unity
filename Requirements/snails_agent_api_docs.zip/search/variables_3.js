var searchData=
[
  ['right_0',['Right',['../struct_snails_1_1_vec2_int.html#a11e0c3845efd141354e570e01b9ad2d2',1,'Snails::Vec2Int']]]
];

var searchData=
[
  ['down_0',['Down',['../struct_snails_1_1_vec2_int.html#a329355f5f5e6fba65ec5a49847116f36',1,'Snails::Vec2Int']]]
];

var searchData=
[
  ['compute_0',['Compute',['../class_snails_1_1_agent_1_1_negamax_agent.html#a13e1bd3005cbeadf2099952328f2fd89',1,'Snails.Agent.NegamaxAgent.Compute()'],['../class_snails_1_1_agent_1_1_player_agent.html#ae667579be222d04a4b1f3760cba1575b',1,'Snails.Agent.PlayerAgent.Compute()']]],
  ['computenextmoveasync_1',['ComputeNextMoveAsync',['../interface_snails_1_1_agent_1_1_i_player_agent.html#a8c9000ac84eebe985bfdac89d38fae79',1,'Snails.Agent.IPlayerAgent.ComputeNextMoveAsync()'],['../class_snails_1_1_agent_1_1_player_agent.html#a71f80fbb9cf1bd640f5e3825e58bd912',1,'Snails.Agent.PlayerAgent.ComputeNextMoveAsync()']]],
  ['constraints_2',['Constraints',['../struct_snails_1_1_agent_1_1_constraints.html#a6702ee65b38d6d13ebd54929d1832139',1,'Snails::Agent::Constraints']]]
];

var searchData=
[
  ['playeragent_0',['PlayerAgent',['../class_snails_1_1_agent_1_1_player_agent.html',1,'Snails::Agent']]]
];

var searchData=
[
  ['this_5bint_20x_2c_20int_20y_5d_0',['this[int x, int y]',['../interface_snails_1_1_i_world_state.html#a585750ce9e25d380dcf3ac6bc0fb2c8f',1,'Snails.IWorldState.this[int x, int y]()'],['../class_snails_1_1_world_state.html#a1378d93b761963ea067bb0e62f9b28c1',1,'Snails.WorldState.this[int x, int y]()']]],
  ['turn_1',['Turn',['../interface_snails_1_1_i_world_state.html#a5597579c806f7fce390fa652e54c412b',1,'Snails.IWorldState.Turn()'],['../class_snails_1_1_world_state.html#a392f0f540fbb5af53b35ce6a2ae1de2c',1,'Snails.WorldState.Turn()']]]
];

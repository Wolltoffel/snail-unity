var searchData=
[
  ['up_0',['Up',['../struct_snails_1_1_vec2_int.html#a9d7ac1e90e1d53d9e1f35916d34398dc',1,'Snails::Vec2Int']]]
];

var searchData=
[
  ['player_0',['Player',['../interface_snails_1_1_i_world_state.html#a75923fefd018a9094ddef77d77794bf9',1,'Snails.IWorldState.Player()'],['../struct_snails_1_1_tile_data.html#abf16e446085eb573db898134c3c83154',1,'Snails.TileData.Player()'],['../class_snails_1_1_world_state.html#a9c020fde9f3d44b9b268f2f7fb40c397',1,'Snails.WorldState.Player()']]]
];

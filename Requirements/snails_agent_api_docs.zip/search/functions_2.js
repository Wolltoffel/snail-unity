var searchData=
[
  ['tiledata_0',['TileData',['../struct_snails_1_1_tile_data.html#a23fb19a74a028e7a6e04208664e0b2f3',1,'Snails.TileData.TileData(ContentType contents, uint player=0)'],['../struct_snails_1_1_tile_data.html#aa457ca49f2f90de6fd6647a4df7cd1b7',1,'Snails.TileData.TileData(byte data)']]],
  ['tostring_1',['ToString',['../struct_snails_1_1_tile_data.html#aa6eb7bf0959d58c9e820d76153313a0e',1,'Snails.TileData.ToString()'],['../struct_snails_1_1_vec2_int.html#a3c045cc1195685fc1424db753e56e7fc',1,'Snails.Vec2Int.ToString()']]]
];

var searchData=
[
  ['agent_0',['Agent',['../namespace_snails_1_1_agent.html',1,'Snails']]],
  ['snails_1',['Snails',['../namespace_snails.html',1,'']]]
];
